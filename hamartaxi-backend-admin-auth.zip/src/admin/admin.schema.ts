import * as mongoose from 'mongoose';

export const AdminUser = mongoose.model(
  'AdminUser',
  new mongoose.Schema({
    email: String,
    password: String,
    role: { type: String, default: 'SuperAdmin' }
  })
);
