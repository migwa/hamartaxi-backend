import { Injectable } from '@nestjs/common';
import * as bcrypt from 'bcryptjs';
import * as jwt from 'jsonwebtoken';
import { AdminUser } from './admin.schema';

@Injectable()
export class AdminAuthService {
  async login(email: string, password: string) {
    const admin = await AdminUser.findOne({ email });
    if (!admin || !(await bcrypt.compare(password, admin.password))) {
      return null;
    }

    const payload = {
      adminId: admin._id,
      email: admin.email,
      role: admin.role
    };

    return jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '7d' });
  }
}
