import { Body, Controller, Post, UnauthorizedException } from '@nestjs/common';
import { AdminAuthService } from './admin.service';

@Controller('api/admin')
export class AdminController {
  constructor(private readonly adminService: AdminAuthService) {}

  @Post('login')
  async login(@Body() body: { email: string; password: string }) {
    const token = await this.adminService.login(body.email, body.password);
    if (!token) throw new UnauthorizedException('Invalid credentials');
    return { token };
  }
}
