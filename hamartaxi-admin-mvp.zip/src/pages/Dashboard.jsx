export default function Dashboard() {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>🚖 Welcome to Hamartaxi Admin Dashboard</h1>
      <p>This is your control center. Stats and charts coming next.</p>
    </div>
  );
}