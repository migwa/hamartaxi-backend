export default function App() {
  return <div>Hello from Hamartaxi Admin App!</div>;
}